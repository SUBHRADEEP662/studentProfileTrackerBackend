let express = require('express');
let mysql = require('mysql');
var mycrypto=require('crypto');
var key="password";
var algo='aes256';


let app = express();
app.use(express.json());
let db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "signup",
});


app.post("/newsignup",async (req,res)=>{
let {email,password,name,registration,designation,department,roll} = req.body;
var myCipher= mycrypto.createCipher(algo,key);
var encryptPass=myCipher.update(password,'utf8','hex')
    +myCipher.final('hex');
console.log("the email is".email);


if(designation == 'student') {
    db.query('INSERT INTO student (email,password,name,registration,designation,department,roll) VALUES (?,?,?,?,?,?,?)',
[email,encryptPass,name,registration,designation,department,roll],
(err,result)=>{
    if(err){
        res.status(422).send({err:err})
    }else{
        res.status(201).send({message:'Your data inserted succesfully'})
    }
})
}
else {
    db.query('INSERT INTO mentor (email,password,name,designation,department) VALUES (?,?,?,?,?)',
[email,encryptPass,name,designation,department],
(err,result)=>{
    if(err){
        res.status(422).send({err:err})
    }else{
        res.status(201).send({message:'Your data inserted succesfully'})
    }
})
}


});

app.listen(4554,()=>{
    console.log("server is running on port 4554");
});
