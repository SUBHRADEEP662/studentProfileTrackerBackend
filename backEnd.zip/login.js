let express = require('express');
let mysql = require('mysql');
let jwt = require('jsonwebtoken');
let session = require('express-session')
var mycrypto=require('crypto');
var key="password";
var algo='aes256';
var jwtkey='jwtkey';

let app = express();
app.use(express.json());
let db = mysql.createConnection({
    user: "root",
    host: "localhost",
    password: "",
    database: "signup",
});

app.use(session({
    secret: 'creature',
    resave: false,
    saveUninitialized: false,
}))


// app.post("/axioslogin", function (req, res) {

//     let {designation, email, password} = req.body;
//     console.log('the email is'.email);
//     if(designation == 'student'){
//         {
//             db.query(
//                 'SELECT * FROM student WHERE email =?',
//                 [email],
//                 (err, result) => {
//                     if (err) {
//                         res.send({ err: err })
//                     }
//                     else{
//                         console.log("Result: ",result[0].password);
//                         // var decipher = mycrypto.createDecipher(algo, key);
//                         // var decryptedPassword = decipher.update(result[0].password, 'hex', 'utf8' )+decipher.final('utf8');
//                         // console.log(decryptedPassword);
//                     }
    
//                     if (result.length > 0) {
//                         console.log(result[0])
                        
    
//                         let { email, password } = result[0]
//                         var user = {
//                             userEmail: email,
//                             userPassword: password,
//                         }
    
//                         const tokenCode = jwt.sign(user, "secretKey");
//                         res.status(200).send({ access: tokenCode })
//                         console.log("login Sucessful (student table)")
    
    
//                     } else {
//                         res.status(404).send({ message: 'Invalid Credential' });
//                         console.log('Invalid Credential (student table)')
//                     }
//                 }
//             )
//         }
//     }
//     else if(designation == 'mentor') {
//         db.query(
//             'SELECT * FROM mentor WHERE email =?',
//             [email],
//             (err, result) => {
//                 if (err) {
//                     res.send({ err: err })
//                 }
//                 console.log(result)

//                 if (result.length > 0) {
//                     console.log(result[0])

//                     let { email, password } = result[0]
//                     var user = {
//                         userEmail: email,
//                         userPassword: password,
//                     }

//                     const tokenCode = jwt.sign(user, "secretKey");
//                     res.status(200).send({ access: tokenCode })
//                     console.log("login Sucessful (mentor table)")


//                 } else {
//                     res.status(404).send({ message: 'Invalid Credential' });
//                     console.log('Invalid Credential (mentor table)')
//                 }
//             }
//         )

//     }


    
// });




app.post("/axioslogin", function (req, res) {

    let {designation, email, password} = req.body;

    var myCipher= mycrypto.createCipher(algo,key);
    var encpassword=myCipher.update(password,'utf8','hex') + myCipher.final('hex');
    console.log('the pass is',encpassword);
    if(designation == 'student'){
        {
            db.query(
                'SELECT * FROM student WHERE email =?',
                [email],
                (err, result) => {
                    if (err) {
                        res.send({ err: err })
                    }
                    else{
                        console.log("Result: ",result[0].password);
                    }
    
                    if (result.length > 0 && result[0].password == encpassword) {
                        console.log(result[0])
                        
    
                        let { email, password } = result[0]
                        var user = {
                            userEmail: email,
                            userPassword: password,
                        }
    
                        const tokenCode = jwt.sign(user, "secretKey");
                        res.status(200).send({ access: tokenCode })
                        console.log("login Sucessful (student table)")
    
    
                    } else {
                        res.status(404).send({ message: 'Invalid Credential' });
                        console.log('Invalid Credential (student table)')
                        console.log("database pass ", result[0].password);
                        console.log("given pass ", encpassword);
                    }
                }
            )
        }
    }
    else if(designation == 'mentor') {
        db.query(
            'SELECT * FROM mentor WHERE email =?',
            [email],
            (err, result) => {
                if (err) {
                    res.send({ err: err })
                }
                console.log(result)

                if (result.length > 0 && result[0].password == encpassword) {
                    console.log(result[0])

                    let { email, password } = result[0]
                    var user = {
                        userEmail: email,
                        userPassword: password,
                    }

                    const tokenCode = jwt.sign(user, "secretKey");
                    res.status(200).send({ access: tokenCode })
                    console.log("login Sucessful (mentor table)")


                } else {
                    res.status(404).send({ message: 'Invalid Credential' });
                    console.log('Invalid Credential (mentor table)')
                }
            }
        )

    }


    
});

app.listen(4554, () => {
    console.log("server is running on port 4550");
})